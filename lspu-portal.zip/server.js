
const express = require('express');
const session = require('express-session');
const mongoose = require('mongoose');
const multer = require('multer');
const path = require('path');
const bcrypt = require('bcrypt');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));
app.use('/uploads', express.static('uploads'));

app.use(session({
  secret: process.env.SESSION_SECRET || 'mysecret',
  resave: false,
  saveUninitialized: false
}));

// MongoDB
mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true });

// User Schema
const userSchema = new mongoose.Schema({
  username: String,
  password: String,
  name: String,
  age: Number,
  birthday: Date,
  grade: String,
  photo: String,
  attendance: [Date]
});
const User = mongoose.model('User', userSchema);

// File upload
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'uploads'),
  filename: (req, file, cb) => cb(null, Date.now() + path.extname(file.originalname))
});
const upload = multer({ storage });

// Routes
app.post('/login', async (req, res) => {
  const { username, password } = req.body;
  const user = await User.findOne({ username });
  if (user && await bcrypt.compare(password, user.password)) {
    req.session.user = user._id;
    res.redirect('/dashboard.html');
  } else {
    res.send('Login failed');
  }
});

app.post('/register', upload.single('photo'), async (req, res) => {
  const { username, password, name, age, birthday, grade } = req.body;
  const hash = await bcrypt.hash(password, 10);
  const newUser = new User({
    username, password: hash, name, age, birthday, grade,
    photo: req.file.filename, attendance: []
  });
  await newUser.save();
  res.redirect('/');
});

app.post('/mark-attendance', async (req, res) => {
  if (!req.session.user) return res.status(403).send('Unauthorized');
  const user = await User.findById(req.session.user);
  user.attendance.push(new Date());
  await user.save();
  res.redirect('/dashboard.html');
});

app.get('/admin', async (req, res) => {
  const users = await User.find();
  res.json(users);
});

app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
